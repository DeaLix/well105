<?php

use App\Http\Controllers\AuthController;
use App\Http\Controllers\BidangPrestasiController;
use App\Http\Controllers\DaftarPrestasiController;
use App\Http\Controllers\LevelPrestasiController;
use App\Models\DaftarPrestasi;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function (Request $request) {

    if ($request->search) {
        $listOfPrestasi = DaftarPrestasi::where('nama_anak_indonesia', 'like', '%' . $request->search . '%')->get();
    } else {
        $listOfPrestasi = DaftarPrestasi::all();
    }

    return view('welcome', compact('listOfPrestasi'));
})->name('home');

Route::get('login', [AuthController::class, 'loginIndex']);
Route::post('login', [AuthController::class, 'loginPost'])->name('login');
Route::get('register', [AuthController::class, 'registerIndex']);
Route::post('register', [AuthController::class, 'registerPost']);
Route::post('logout', [AuthController::class, 'logout']);

Route::resource('daftar-prestasi', DaftarPrestasiController::class)->middleware('admin', 'auth');
Route::resource('bidang-prestasi', BidangPrestasiController::class)->middleware('admin', 'auth');
Route::resource('level-prestasi', LevelPrestasiController::class)->middleware('admin', 'auth');
