<?php

namespace App\Http\Controllers;

use App\Models\LevelPrestasi;
use Illuminate\Http\Request;

class LevelPrestasiController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $listOfLevel = LevelPrestasi::all();
        return view('level.index', compact('listOfLevel'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('level.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'nama_level' => 'required'
        ]);

        LevelPrestasi::create($validated);

        return redirect('/level-prestasi')->with('success', 'Tambah level berhasil');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\LevelPrestasi  $levelPrestasi
     * @return \Illuminate\Http\Response
     */
    public function show(LevelPrestasi $levelPrestasi)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\LevelPrestasi  $levelPrestasi
     * @return \Illuminate\Http\Response
     */
    public function edit(LevelPrestasi $levelPrestasi)
    {
        return view('level.edit', compact('levelPrestasi'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\LevelPrestasi  $levelPrestasi
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, LevelPrestasi $levelPrestasi)
    {
        $validated = $request->validate([
            'nama_level' => 'required'
        ]);

        $levelPrestasi->update($validated);

        return redirect('/level-prestasi')->with('success', 'Update level berhasil');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\LevelPrestasi  $levelPrestasi
     * @return \Illuminate\Http\Response
     */
    public function destroy(LevelPrestasi $levelPrestasi)
    {
        $levelPrestasi->delete();

        return back()->with('success', 'Delete level berhasil');
    }
}
