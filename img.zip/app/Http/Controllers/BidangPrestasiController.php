<?php

namespace App\Http\Controllers;

use App\Models\BidangPrestasi;
use Illuminate\Http\Request;

class BidangPrestasiController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $listOfBidang = BidangPrestasi::all();
        return view('bidang.index', compact('listOfBidang'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {

        return view('bidang.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'nama_bidang' => 'required'
        ]);

        BidangPrestasi::create($validated);

        return redirect('/bidang-prestasi')->with('success', 'Tambah bidang berhasil');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\BidangPrestasi  $bidangPrestasi
     * @return \Illuminate\Http\Response
     */
    public function show(BidangPrestasi $bidangPrestasi)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\BidangPrestasi  $bidangPrestasi
     * @return \Illuminate\Http\Response
     */
    public function edit(BidangPrestasi $bidangPrestasi)
    {
        return view('bidang.edit', compact('bidangPrestasi'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\BidangPrestasi  $bidangPrestasi
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, BidangPrestasi $bidangPrestasi)
    {
        $validated = $request->validate([
            'nama_bidang' => 'required'
        ]);

        $bidangPrestasi->update($validated);

        return redirect('/bidang-prestasi')->with('success', 'Update bidang berhasil');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\BidangPrestasi  $bidangPrestasi
     * @return \Illuminate\Http\Response
     */
    public function destroy(BidangPrestasi $bidangPrestasi)
    {
        $bidangPrestasi->delete();

        return redirect('/bidang-prestasi')->with('success', 'Delete bidang prestasi');
    }
}
