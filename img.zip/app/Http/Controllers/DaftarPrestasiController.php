<?php

namespace App\Http\Controllers;

use App\Models\BidangPrestasi;
use App\Models\DaftarPrestasi;
use App\Models\LevelPrestasi;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;

class DaftarPrestasiController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $listOfPrestasi = DaftarPrestasi::all();
        return view('daftar.index', compact('listOfPrestasi'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $listOfBidang = BidangPrestasi::all();
        $listOfLevel = LevelPrestasi::all();

        return view('daftar.create', compact('listOfBidang', 'listOfLevel'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'nama_anak_indonesia' => 'required',
            'uraian_prestasi' => 'required',
            'foto' => 'required',
            'id_bidang' => 'required',
            'id_level' => 'required',
        ]);

        $path = $request->file('foto')->store('public');

        $validated['foto'] = str_replace('public', 'storage', $path);

        DaftarPrestasi::create($validated);

        return redirect('/daftar-prestasi')->with('success', 'Tambah daftar prestasi berhasil');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\DaftarPrestasi  $daftarPrestasi
     * @return \Illuminate\Http\Response
     */
    public function show(DaftarPrestasi $daftarPrestasi)
    {
        return view('daftar.show', compact('daftarPrestasi'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\DaftarPrestasi  $daftarPrestasi
     * @return \Illuminate\Http\Response
     */
    public function edit(DaftarPrestasi $daftarPrestasi)
    {
        $listOfBidang = BidangPrestasi::all();
        $listOfLevel = LevelPrestasi::all();

        return view('daftar.edit', compact('daftarPrestasi', 'listOfBidang', 'listOfLevel'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\DaftarPrestasi  $daftarPrestasi
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, DaftarPrestasi $daftarPrestasi)
    {
        $validated = $request->validate([
            'nama_anak_indonesia' => 'required',
            'uraian_prestasi' => 'required',
            'foto' => 'nullable',
            'id_bidang' => 'required',
            'id_level' => 'required',
        ]);

        // jika ada request foto maka simpn foto baru
        if ($request->file('foto')) {
            // hapus foto lama
            File::delete($request->oldfoto);

            // simpan foto baru
            $path = $request->file('foto')->store('public');
            $validated['foto'] = str_replace('public', 'storage', $path);
        } else {
            $validated['foto'] = $request->oldfoto;
        }

        $daftarPrestasi->update($validated);

        return redirect('/daftar-prestasi')->with('success', 'Update data berhasil');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\DaftarPrestasi  $daftarPrestasi
     * @return \Illuminate\Http\Response
     */
    public function destroy(DaftarPrestasi $daftarPrestasi)
    {
        $daftarPrestasi->delete();

        return redirect('/daftar-prestasi')->with('success', 'Delete prestasi berhasil');
    }
}
