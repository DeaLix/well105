@extends('template')

@section('content')
    <div class="container text-center">
        <div class="mb-4">
            <h1 class="display-6">Edit Prestasi</h1>
            <a href="/daftar-prestasi" class="btn btn-primary">Kembali</a>
        </div>
        <div class="container text-start">
            <form action="/daftar-prestasi/{{ $daftarPrestasi->id }}" method="POST" enctype="multipart/form-data">
                @method('put')
                @csrf
                <div class="mb-3">
                    <label for="nama_anak_indonesia" class="form-label">Nama Anak</label>
                    <input type="text" class="form-control" name="nama_anak_indonesia" id="nama_anak_indonesia"
                        placeholder="masukkan nama anak" value="{{ $daftarPrestasi->nama_anak_indonesia }}">
                    @error('nama_anak_indonesia')
                        <p class="text-danger">{{ $message }}</p>
                    @enderror
                </div>
                <div class="mb-3">
                    <label for="uraian_prestasi" class="form-label">Uraian</label>
                    <textarea class="form-control" name="uraian_prestasi" id="uraian_prestasi" rows="3">{{ $daftarPrestasi->uraian_prestasi }}</textarea>
                    @error('uraian_prestasi')
                        <p class="text-danger">{{ $message }}</p>
                    @enderror
                </div>

                <div class="mb-3">
                    <input type="hidden" value="{{ $daftarPrestasi->foto }}" name="oldfoto">
                    <label for="foto" class="form-label">Foto</label>
                    <input class="form-control" name="foto" type="file" id="foto">
                </div>
                <div class="mb-3">
                    <label for="id_bidang" class="form-label">Bidang</label>
                    <select class="form-select" aria-label="Default select example" name="id_bidang">
                        <option selected value="">Pilih Bidang</option>
                        @foreach ($listOfBidang as $item)
                            <option value="{{ $item->id }}"
                                {{ $item->id == $daftarPrestasi->id_bidang ? 'selected' : '' }}>{{ $item->nama_bidang }}
                            </option>
                        @endforeach
                    </select>
                    @error('id_bidang')
                        <p class="text-danger">{{ $message }}</p>
                    @enderror
                </div>
                <div class="mb-3">
                    <label for="id_level" class="form-label">Level</label>
                    <select class="form-select" aria-label="Default select example" name="id_level">
                        <option selected value="">Pilih Level</option>
                        @foreach ($listOfLevel as $item)
                            <option value="{{ $item->id }}"
                                {{ $item->id == $daftarPrestasi->id_level ? 'selected' : '' }}>{{ $item->nama_level }}
                            </option>
                        @endforeach
                    </select>
                    @error('id_level')
                        <p class="text-danger">{{ $message }}</p>
                    @enderror
                </div>
                <div class="mb-3">
                    <button type="submit" class="btn btn-success">Simpan</button>
                </div>
            </form>
        </div>

    </div>
@endsection
