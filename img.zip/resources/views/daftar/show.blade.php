@extends('template')

@section('content')
    <div class="container text-center">
        <div class="mb-4">
            <h1 class="display-6">Detail Prestasi</h1>
            <a href="/daftar-prestasi" class="btn btn-primary">Kembali</a>
        </div>
        <div class="container text-start">
            <div>
                <div class="mb-3">
                    <label for="nama_anak_indonesia" class="form-label">Nama Anak</label>
                    <input type="text" class="form-control" name="nama_anak_indonesia"
                        value="{{ $daftarPrestasi->nama_anak_indonesia }}" id="nama_anak_indonesia"
                        placeholder="masukkan nama anak" aria-label="Disabled input example" disabled>
                </div>
                <div class="mb-3">
                    <label for="uraian_prestasi" class="form-label">Uraian</label>
                    <textarea class="form-control" name="uraian_prestasi" id="uraian_prestasi" rows="3"
                        aria-label="Disabled input example" disabled>{{ $daftarPrestasi->uraian_prestasi }}</textarea>
                </div>
                <div class="mb-3">
                    <label for="foto" class="form-label">Foto</label>
                    <img src="/{{ $daftarPrestasi->foto }}" class="rounded d-block img-thumbnail" width="300"
                        alt="image">
                </div>
                <div class="mb-3">
                    <label for="id_bidang" class="form-label">Bidang</label>
                    <input type="text" class="form-control" name="id_bidang"
                        value="{{ $daftarPrestasi->bidang->nama_bidang }}" id="id_bidang" placeholder="masukkan nama anak"
                        aria-label="Disabled input example" disabled>
                </div>
                <div class="mb-3">
                    <label for="id_level" class="form-label">Level</label>
                    <input type="text" class="form-control" name="id_level"
                        value="{{ $daftarPrestasi->level->nama_level }}" id="id_level" placeholder="masukkan nama anak"
                        aria-label="Disabled input example" disabled>
                </div>
            </div>
        </div>

    </div>
@endsection
