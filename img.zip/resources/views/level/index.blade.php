@extends('template')

@section('content')
    <div class="container text-center">
        <div class="mb-4">
            <h1 class="display-6">Level Prestasi</h1>
            <a href="/level-prestasi/create" class="btn btn-primary">Tambah level</a>
        </div>

        @if (session('success'))
            <div class="alert alert-success" role="alert">
                {{ session('success') }}
            </div>
        @endif

        <div>
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Nama level</th>
                        <th scope="col">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($listOfLevel as $item)
                        <tr>
                            <th scope="row">{{ $loop->iteration }}</th>
                            <td>{{ $item->nama_level }}</td>
                            <td>
                                <form action="/level-prestasi/{{ $item->id }}" method="POST">
                                    @method('delete')
                                    @csrf
                                    <div class="btn-group" role="group" aria-label="Basic mixed styles example">
                                        <button type="submit" class="btn btn-danger">Hapus</button>
                                        <a href="/level-prestasi/{{ $item->id }}/edit" class="btn btn-warning">Edit</a>
                                    </div>
                                </form>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>

    </div>
@endsection
