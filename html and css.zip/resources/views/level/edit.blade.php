@extends('template')

@section('content')
    <div class="container text-center">
        <div class="mb-4">
            <h1 class="display-6">Edit Level Prestasi</h1>
            <a href="/level-prestasi" class="btn btn-primary">Kembali</a>
        </div>
        <div class="container text-start">
            <form action="/level-prestasi/{{ $levelPrestasi->id }}" method="POST" enctype="multipart/form-data">
                @method('put')
                @csrf
                <div class="mb-3">
                    <label for="nama_level" class="form-label">Nama Level Prestasi</label>
                    <input type="text" class="form-control" name="nama_level" value="{{ $levelPrestasi->nama_level }}"
                        id="nama_level" placeholder="masukkan nama level prestasi">
                    @error('nama_level')
                        <p class="text-danger">{{ $message }}</p>
                    @enderror
                </div>
                <div class="mb-3">
                    <button type="submit" class="btn btn-success">Simpan</button>
                </div>
            </form>
        </div>

    </div>
@endsection
