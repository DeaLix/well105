@extends('template')

@section('content')
    <div class="container text-center">
        <div class="mb-4">
            <h1 class="display-6">Daftar Prestasi</h1>
            <a href="/daftar-prestasi/create" class="btn btn-primary">Tambah prestasi</a>
        </div>

        @if (session('success'))
            <div class="alert alert-success" role="alert">
                {{ session('success') }}
            </div>
        @endif
        <div>
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Foto</th>
                        <th scope="col">Nama</th>
                        <th scope="col">Bidang</th>
                        <th scope="col">Level</th>
                        <th scope="col">Uraian</th>
                        <th scope="col">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($listOfPrestasi as $item)
                        <tr>
                            <th scope="row">{{ $loop->iteration }}</th>
                            <td><img src="{{ $item->foto }}" class="rounded mx-auto d-block img-thumbnail" width="100"
                                    alt="image">
                            </td>
                            <td>{{ $item->nama_anak_indonesia }}</td>
                            <td>{{ $item->id_bidang }}</td>
                            <td>{{ $item->id_level }}</td>
                            <td>{{ $item->uraian_prestasi }}</td>
                            <td>
                                <form action="/daftar-prestasi/{{ $item->id }}" method="POST">
                                    @method('delete')
                                    @csrf
                                    <div class="btn-group" role="group" aria-label="Basic mixed styles example">
                                        <button type="submit" class="btn btn-danger">Hapus</button>
                                        <a href="/daftar-prestasi/{{ $item->id }}/edit" class="btn btn-warning">Edit</a>
                                        <a href="/daftar-prestasi/{{ $item->id }}" class="btn btn-success">Detail</a>
                                    </div>
                                </form>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>

    </div>
@endsection
