@extends('template')

@section('content')
    <div class="container">
        <div class=" mb-5">
            <h1 class="display-1">Prestasi</h1>

            <form action="/" method="GET">
                @csrf
                <div class="row">
                    <div class="col-5">
                        <input class="mx-auto form-control " name="search" list="datalistOptions" id="exampleDataList"
                            placeholder="Type to search...">
                    </div>
                    <div class="col-2">
                        <button type="submit" class="btn btn-success">cari</button>
                        <a href="/" class="btn btn-secondary">reset</a>
                    </div>
                </div>
            </form>
        </div>
        <div class="row">

            @foreach ($listOfPrestasi as $item)
                <div class="col">
                    <div class="card" style="width: 18rem;">
                        <img src="/{{ $item->foto }}" width="200" class="card-img-top" alt="...">
                        <div class="card-body">
                            <h5 class="card-title">{{ $item->nama_anak_indonesia }}</h5>
                            <p class="card-text">{{ $item->uraian_prestasi }}</p>
                        </div>
                    </div>
                </div>
            @endforeach

        </div>
    </div>
@endsection
