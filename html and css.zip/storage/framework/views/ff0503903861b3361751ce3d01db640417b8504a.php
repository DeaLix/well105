<?php $__env->startSection('content'); ?>
    <div class="container text-center">
        <div class="mb-4">
            <h1 class="display-6">Daftar</h1>
            <a href="/daftar-presensi" class="btn btn-primary">Tambah prestasi</a>
        </div>
        <div>
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Foto</th>
                        <th scope="col">Nama</th>
                        <th scope="col">Bidang</th>
                        <th scope="col">Level</th>
                        <th scope="col">Uraian</th>
                        <th scope="col">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <th scope="row">1</th>
                        <td><img src="/img/foto-anak.jpg" class="rounded mx-auto d-block img-thumbnail" width="100"
                                alt="image">
                        </td>
                        <td>Otto</td>
                        <td>@mdo</td>
                        <td>@mdo</td>
                        <td>@mdo</td>
                        <td>
                            <div class="btn-group" role="group" aria-label="Basic mixed styles example">
                                <button type="button" class="btn btn-danger">Hapus</button>
                                <button type="button" class="btn btn-warning">Edit</button>
                                <button type="button" class="btn btn-success">Detail</button>
                            </div>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\prestasi-app\resources\views/daftar.blade.php ENDPATH**/ ?>