<?php $__env->startSection('content'); ?>
    <div class="container text-center">
        <div class="mb-4">
            <h1 class="display-6">Daftar Prestasi</h1>
            <a href="/daftar-prestasi/create" class="btn btn-primary">Tambah prestasi</a>
        </div>

        <?php if(session('success')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
        <div>
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Foto</th>
                        <th scope="col">Nama</th>
                        <th scope="col">Bidang</th>
                        <th scope="col">Level</th>
                        <th scope="col">Uraian</th>
                        <th scope="col">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $listOfPrestasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e($loop->iteration); ?></th>
                            <td><img src="<?php echo e($item->foto); ?>" class="rounded mx-auto d-block img-thumbnail" width="100"
                                    alt="image">
                            </td>
                            <td><?php echo e($item->nama_anak_indonesia); ?></td>
                            <td><?php echo e($item->id_bidang); ?></td>
                            <td><?php echo e($item->id_level); ?></td>
                            <td><?php echo e($item->uraian_prestasi); ?></td>
                            <td>
                                <form action="/daftar-prestasi/<?php echo e($item->id); ?>" method="POST">
                                    <?php echo method_field('delete'); ?>
                                    <?php echo csrf_field(); ?>
                                    <div class="btn-group" role="group" aria-label="Basic mixed styles example">
                                        <button type="submit" class="btn btn-danger">Hapus</button>
                                        <a href="/daftar-prestasi/<?php echo e($item->id); ?>/edit" class="btn btn-warning">Edit</a>
                                        <a href="/daftar-prestasi/<?php echo e($item->id); ?>" class="btn btn-success">Detail</a>
                                    </div>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\prestasi-app\resources\views/daftar/index.blade.php ENDPATH**/ ?>