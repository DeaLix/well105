<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class=" mb-5">
            <h1 class="display-1">Prestasi</h1>

            <form action="/" method="GET">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-5">
                        <input class="mx-auto form-control " name="search" list="datalistOptions" id="exampleDataList"
                            placeholder="Type to search...">
                    </div>
                    <div class="col-2">
                        <button type="submit" class="btn btn-success">cari</button>
                        <a href="/" class="btn btn-secondary">reset</a>
                    </div>
                </div>
            </form>
        </div>
        <div class="row">

            <?php $__currentLoopData = $listOfPrestasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col">
                    <div class="card" style="width: 18rem;">
                        <img src="/<?php echo e($item->foto); ?>" width="200" class="card-img-top" alt="...">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($item->nama_anak_indonesia); ?></h5>
                            <p class="card-text"><?php echo e($item->uraian_prestasi); ?></p>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\prestasi-app\resources\views/welcome.blade.php ENDPATH**/ ?>