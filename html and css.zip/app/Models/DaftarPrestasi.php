<?php

namespace App\Models;

use App\Http\Controllers\LevelPrestasiController;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DaftarPrestasi extends Model
{
    use HasFactory;

    protected $fillable = [
        'nama_anak_indonesia',
        'uraian_prestasi',
        'foto',
        'id_bidang',
        'id_level',
    ];

    public function bidang()
    {
        return $this->belongsTo(BidangPrestasi::class, 'id_bidang', 'id');
    }

    public function level()
    {
        return $this->belongsTo(LevelPrestasi::class, 'id_level', 'id');
    }
}
